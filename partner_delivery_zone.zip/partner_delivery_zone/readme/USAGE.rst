To use this module you need to:

#. Got to *Sales > Settings > Delivery Zones*
#. Create some delivery zones.
#. Go to *Sales > Customers*.
#. Go to *Sales and Purchases* tab.
#. Set a delivery zone for this partner in *Delivery Zone* field.
#. Got to *Sales > Quotations*
#. Create a quotation, automatically delivery zone field is filled. Confirm
   it.
#. Open the picking and you can see the delivery zone in
   'Aditional Information' tab.
